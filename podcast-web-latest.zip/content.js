/* =========================================================
   ONE GLIMPSE PODCAST · 内容数据（可持续更新 · 单数据源）
   —— 改内容只动这个文件。
   · SITE.hosts      ：主播/嘉宾注册表（首页与单集共用，点头像弹窗）
   · SITE.site       ：首页品牌数据（关于/订阅/页脚…）
   · SITE.episodes   ：单集数组。加一集 = 往这里加一个对象。
       每集字段：id / number / title / date / cover / hosts / intro …
       详情弹框内容由 episodes[i].principles / comparison /
       counterexamples / international / books 等结构数据驱动。
   首页与单集共享 brand / subscribe / footer。
   ========================================================= */
window.SITE = {
  /* ---------- 全局 SEO ---------- */
  meta: {
    title: "ONE GLIMPSE PODCAST · 惊鸿一瞥",
    description: "一档用方法拆穿流行叙事的播客。结构性原则 × 关系性原则，带你看见现象背后的生产关系。",
    lang: "zh-CN",
  },

  brand: {
    name: "ONE GLIMPSE PODCAST",
    cn: "惊鸿一瞥",
    slogan: "聪明本身，就是一种吸引力。",
    logo: "assets/logo-wide.png",
    favicon: "assets/favicon.png",
  },

  /* =========================================================
     主播 / 嘉宾注册表（点击头像弹窗）
     占位字段（bio / socials）保留结构，方便你后续补真实内容。
     ========================================================= */
  hosts: {
    "host-a": {
      id: "host-a",
      name: "A · 主理人",
      role: "主理人 / 智性恋观察员",
      avatar: "assets/ip-avatar-1.jpg",
      alt: "主理人 IP 形象（灰麻花辫）",
      bio: "【占位】主播个人简介待补充。",
      socials: [
        { label: "微博", href: "#" },
        { label: "小红书", href: "#" },
        { label: "邮箱", href: "mailto:hello@example.com" },
      ],
    },
    "host-b": {
      id: "host-b",
      name: "B · 研究员",
      role: "研究员 / 媒介社会学",
      avatar: "assets/ip-avatar-2.jpg",
      alt: "研究员 IP 形象（白 Polo）",
      bio: "【占位】主播个人简介待补充。",
      socials: [
        { label: "微博", href: "#" },
        { label: "公众号", href: "#" },
        { label: "邮箱", href: "mailto:hello@example.com" },
      ],
    },
  },

  /* =========================================================
     首页（品牌）数据
     ========================================================= */
  site: {
    nav: [
      { label: "首页", href: "index.html" },
      { label: "单集", href: "index.html#episodes" },
      { label: "订阅", href: "index.html#subscribe" },
    ],
    navCta: { label: "听最新一期", href: "episode.html?id=ep01" },

    /* Hero（用到：双人播客交流视频 + 两个 IP 头像，头像可点头像弹窗） */
    hero: {
      tag: "播客 · PODCAST",
      title: "一眼，看穿流行叙事。",
      cn: "",
      desc: "我们是一档用方法拆穿流行叙事的播客。每期挑一个被嚼烂的网络现象，用两把方法钥匙——结构性原则与关系性原则——把它拆开，看见背后那整套生产关系。",
      ctaPrimary: { label: "▶ 进入 EP01", href: "episode.html?id=ep01" },
      ctaSecondary: { label: "✉ 订阅更新", href: "#subscribe" },
      video: "assets/double-podcast.mp4",
      avatars: ["host-a", "host-b"],
      scribbles: ["stay curious", "结构 × 关系", "two keys", "to be continued"],
    },

    about: {
      title: "我们在做什么",
      paragraphs: [
        "ONE GLIMPSE 是一档双人播客。一个主理人，一个研究员，把被当成“个人口味”的事，放回它真正的结构里。",
        "我们相信：你以为你在刷喜好，其实你刷到的是一整套生产关系。所以每期我们都不吵架，只拆方法。",
      ],
      stats: [
        { n: "2", l: "把方法钥匙" },
        { n: "∞", l: "个流行现象" },
        { n: "1", l: "档不糊弄的播客" },
      ],
    },

    subscribe: {
      title: "加入 ONE GLIMPSE，每周一瞥思想的回声。",
      placeholder: "留下你的邮箱，新节目上线第一时间通知你",
      button: "订阅",
      socials: [
        { label: "小宇宙", href: "#" },
        { label: "Apple Podcasts", href: "#" },
        { label: "Spotify", href: "#" },
      ],
    },

    footer: { note: "Made by MengHan", year: 2026 },
  },

  /* =========================================================
     单集数组（持续加集 = 往这里加一个对象）
     必填：id / number / title / date / cover / hosts / intro
     hosts 为 SITE.hosts 的 id 数组；详情弹框由下方结构字段驱动。
     ========================================================= */
  episodes: [
    {
      id: "ep01",
      number: "EP.01",
      title: "小红书上的“智性恋” 和 TikTok 上的 nerd TikTok 是一回事吗？",
      subtitle: "结构性原则 × 关系性原则",
      date: "2026/05/20",
      duration: "08:00",
      tag: "国际传播 × 媒介社会学",
      cover: "assets/ip-avatar-1.jpg",
      coverAlt: "EP01 封面：主播 IP 形象",
      hosts: ["host-a", "host-b"],
      intro: "同一份“聪明”，在两个平台上长成了完全不同的东西。我们用两把方法钥匙，拆开它到底是审美差异，还是一整套生产关系。",
      meta: {
        title: "ONE GLIMPSE PODCAST · EP01",
        description: "小红书上的“智性恋”和 TikTok 上的 nerd TikTok 是一回事吗？用结构性原则 × 关系性原则拆开它。",
      },

      /* 音频占位：拿到真实 mp3 后填路径，例如 "assets/ep01.mp3" */
      audio: "",

      player: {
        cover: "assets/ip-avatar-1.jpg",
        coverAlt: "EP01 封面",
        title: "EP.01：当“聪明”成为吸引力",
        duration: "08:00",
        meta: "2026/05/20 · 国际传播 × 媒介社会学 · 双原则拆解",
        chapters: [
          { id: "intro", label: "引入", sec: 0 },
          { id: "phenom", label: "现象", sec: 45 },
          { id: "struct", label: "结构", sec: 150, theme: "struct" },
          { id: "relate", label: "关系", sec: 285, theme: "relate" },
          { id: "counter", label: "反证", sec: 440 },
        ],
      },

      /* —— 以下为 EP01 主题化数据，驱动单集详情弹框 —— */
      principles: [
        {
          id: "struct",
          theme: "struct",
          icon: "⚙️",
          name: "结构性原则",
          oneLiner: "要素的结合方式，决定系统的功能。",
          desc: "平台不是空容器。谁生产、为谁生产、靠什么激励、算法怎么推——这些关系合在一起，决定了同一个话题会长成什么样子。",
          layers: [
            { t: "生产者结构", d: "小红书核心是生活方式博主，变现靠人设与种草；TikTok 的 nerd 内容生产者多是从业者或爱好者，变现路径更弱也更多元。" },
            { t: "用户结构", d: "小红书以女性用户为主，择偶与亲密关系是核心话题；TikTok 用户更年轻多元，nerd 内容是亚文化圈层的事。" },
            { t: "算法结构", d: "小红书强推“人设+场景”，催生“学霸男友”式模板内容；TikTok 强推“梗+参与”，催生模仿与二次创作。" },
          ],
          flow: "内容形态差异",
          conclusion: "三层结构叠加，同样的“智性魅力”在小红书长成“女性凝视下的择偶审美”，在 TikTok 长成“亚文化群体的自我表达”。",
        },
        {
          id: "relate",
          theme: "relate",
          icon: "🔗",
          name: "关系性原则",
          oneLiner: "人的偏好，是社会关系的产物。",
          desc: "为什么“聪明”在这个时代会变成一种明确的吸引力？不是人突然变了，而是社会关系变了。",
          layers: [
            { t: "教育关系", d: "高等教育普及，女性受教育程度甚至超过男性，“智力”从稀缺品变成日常接触物——越熟悉，越能欣赏。" },
            { t: "经济关系", d: "女性经济独立，不再需要靠婚姻解决生存，“择偶标准”从“找依靠”变成“找同频”，智力与三观权重上升。" },
            { t: "性别关系", d: "“男强女弱”模式松动，女性不再需要找“比自己强”的依靠，但“智识上的匹配”成了新的平等诉求——聪明不是“强”，是“同频”。" },
          ],
          flow: "智性魅力成为吸引力",
          conclusion: "结构性原则解释“为什么平台上长这样”（媒介生产层面），关系性原则解释“为什么这个话题会火”（社会基础层面）。",
        },
      ],

      comparison: {
        xiaohongshu: {
          tag: "小红书",
          theme: "struct",
          stat: "60%+ 热门内容是女性博主在“晒”或“评”男性",
          keywords: ["学霸滤镜", "心动", "择偶", "人设"],
          core: "女性凝视下的择偶审美",
          points: [
            "生产者：生活方式博主，靠人设与种草变现",
            "用户：女性为主，择偶与亲密关系是核心话题",
            "算法：强推“人设+场景”，易催生模板化内容",
            "关键词：滤镜 / 心动 / 择偶",
          ],
        },
        tiktok: {
          tag: "TikTok",
          theme: "relate",
          stat: "nerd 群体以自我表达为主，女性视角非主流",
          keywords: ["梗", "社区", "身份", "亚文化"],
          core: "亚文化群体的自我表达",
          points: [
            "生产者：从业者或爱好者，变现弱而多元",
            "用户：年轻多元，nerd 是亚文化圈层的事",
            "算法：强推“梗+参与”，易催生二次创作",
            "关键词：梗 / 社区 / 身份",
          ],
        },
      },

      international: {
        title: "国际传播视角：同一个概念，被重构了两次",
        points: [
          "很多人以为“智性恋”是西方传进来的概念，但同一概念进入不同的媒介结构与社会关系，会被重构成完全不同的东西。",
          "西方的 nerd 形象演变，与硅谷崛起、科技新贵文化地位上升有关——它本就是群体身份政治的产物：从被嘲笑到被追捧。",
          "到了中国，它经小红书过滤，变成了女性择偶话语。不是 nerd 群体在自我表达，而是女性用户在表达“我欣赏什么样的男性”。主体变了，意义也就变了。",
        ],
      },

      counterexamples: [
        { theme: "struct", label: "结构性原则的反证", text: "如果以后 TikTok 上也出现大量女性视角的 nerd 内容，那么“结构决定内容形态”的判断就需要修正。" },
        { theme: "relate", label: "关系性原则的反证", text: "如果经济欠发达地区的女性也普遍表达这种偏好，那么“经济独立是基础”的假设就要打个问号。" },
        { theme: "neutral", label: "边界提醒", text: "我们讨论的是平台上的话语呈现，不等于现实中的真实偏好。" },
      ],

      books: [
        { title: "思考，快与慢", author: "Daniel Kahneman", note: "读懂“直觉”和“理性”怎么打架。", cover: "assets/books.png", alt: "《思考，快与慢》封面占位" },
        { title: "置身事内", author: "兰小欢", note: "理解中国经济与社会关系变迁。", cover: "assets/books.png", alt: "《置身事内》封面占位" },
        { title: "过滤泡", author: "Eli Pariser", note: "当算法替我们决定看到什么。", cover: "assets/books.png", alt: "《过滤泡》封面占位" },
      ],

      /* 本期内容矩阵：3 张精选卡片（参考 one-glimpse 视觉，3 卡一行）。
         matrix = 主卡片；more = 次级章节（小药丸，点开同样弹框，避免长图）。 */
      matrix: [
        { type: "compare",    no: "01", color: "struct", icon: "⚖️", title: "本期现象",   sub: "小红书 × TikTok，同一个“聪明”两种长相" },
        { type: "principles", no: "",   color: "relate", icon: "🔑", title: "双原则解析", sub: "结构 × 关系，两把钥匙拆开它" },
        { type: "links",      no: "03", color: "ink",    icon: "🔗", title: "延伸阅读",   sub: "3 本书，读懂现象背后的结构" },
      ],
      more: [
        { type: "intro" },
        { type: "timeline" },
        { type: "counterex" },
        { type: "international" },
        { type: "clip" },
        { type: "hosts" },
      ],

      episodeNav: {
        prev: null,
        next: { label: "EP02 预告", title: "智性恋到底是女性独立的表现，还是换了包装的“上迁婚”？", href: "#" },
      },
    },
  ],
};
