/* =========================================================
   ONE GLIMPSE PODCAST · 渲染逻辑（首页 + 动态单集页 + 弹框系统）
   读取 window.SITE（content.js）。
   · 存在 #home-root    → renderHome（品牌首页 · 单集卡片列表）
   · 存在 #episode-root → renderEpisode（单集详情，读 ?id=）
   改内容去 content.js，一般不用改这个文件。
   ========================================================= */
(function () {
  "use strict";
  const S = window.SITE;
  if (!S) { console.error("缺少 content.js 中的 SITE 数据"); return; }
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const el = (tag, cls, html) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  };
  const setMeta = (name, content, isProp) => {
    let m = document.querySelector(isProp ? `meta[property="${name}"]` : `meta[name="${name}"]`);
    if (!m) { m = document.createElement("meta"); if (isProp) m.setAttribute("property", name); else m.setAttribute("name", name); document.head.appendChild(m); }
    m.setAttribute("content", content);
  };
  const fmt = (sec) => { const m = Math.floor(sec / 60); const s = sec % 60; return m + ":" + String(s).padStart(2, "0"); };

  /* 页面分流 */
  if (document.getElementById("home-root")) renderHome(S);
  else if (document.getElementById("episode-root")) {
    const id = new URLSearchParams(location.search).get("id") || (S.episodes[0] && S.episodes[0].id);
    const ep = S.episodes.find(e => e.id === id) || S.episodes[0];
    renderEpisode(S, ep);
  }

  /* =======================================================
     通用模态框（遮罩 / 关闭 / Esc / 焦点管理）
     ======================================================= */
  let lastFocused = null;
  function ensureModal() {
    let overlay = $("#modal-overlay");
    if (overlay) return overlay;
    overlay = el("div", "modal-overlay");
    overlay.id = "modal-overlay";
    overlay.setAttribute("role", "presentation");
    overlay.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <button class="modal-close" type="button" aria-label="关闭">×</button>
        <h3 class="modal-title" id="modal-title"></h3>
        <div class="modal-body" id="modal-body"></div>
      </div>`;
    document.body.appendChild(overlay);
    overlay.addEventListener("click", (e) => { if (e.target === overlay) closeModal(); });
    overlay.querySelector(".modal-close").addEventListener("click", closeModal);
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && overlay.classList.contains("open")) closeModal();
      if (e.key === "Tab" && overlay.classList.contains("open")) trapFocus(e, overlay);
    });
    return overlay;
  }
  function trapFocus(e, overlay) {
    const f = $$('a[href], button:not([disabled]), input, [tabindex]:not([tabindex="-1"])', overlay).filter(n => n.offsetParent !== null);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
  function openModal(title, bodyNode) {
    const overlay = ensureModal();
    $("#modal-title").textContent = title;
    const body = $("#modal-body");
    body.innerHTML = "";
    body.appendChild(bodyNode);
    lastFocused = document.activeElement;
    overlay.classList.add("open");
    document.body.style.overflow = "hidden";
    const closeBtn = overlay.querySelector(".modal-close");
    if (closeBtn) closeBtn.focus();
  }
  function closeModal() {
    const overlay = $("#modal-overlay");
    if (!overlay || !overlay.classList.contains("open")) return;
    overlay.classList.remove("open");
    document.body.style.overflow = "";
    if (lastFocused && typeof lastFocused.focus === "function") lastFocused.focus();
  }

  /* 宿主弹框（点头像触发） */
  function openHostModal(hostId) {
    const h = (S.hosts && S.hosts[hostId]) || null;
    if (!h) return;
    const node = el("div", "host-modal");
    node.innerHTML = `
      <img class="hm-avatar" src="${h.avatar}" alt="${h.alt}" width="96" height="96">
      <div class="hm-name">${h.name}</div>
      <div class="hm-role">${h.role}</div>
      <p class="hm-bio">${h.bio}</p>
      <div class="hm-socials"></div>`;
    const soc = node.querySelector(".hm-socials");
    (h.socials || []).forEach(s => {
      const a = el("a", "hm-social", s.label);
      a.setAttribute("href", s.href);
      a.setAttribute("target", s.href && s.href.startsWith("http") ? "_blank" : "_self");
      if (s.href && s.href.startsWith("http")) a.setAttribute("rel", "noopener");
      soc.appendChild(a);
    });
    openModal(h.name, node);
  }

  /* =======================================================
     首页渲染（品牌 · 单集卡片列表为主）
     ======================================================= */
  function renderHome(S) {
    const site = S.site, brand = S.brand;
    document.documentElement.lang = S.meta.lang || "zh-CN";
    document.title = S.meta.title;
    setMeta("description", S.meta.description);
    setMeta("og:title", S.meta.title, true);
    setMeta("og:description", S.meta.description, true);
    setMeta("og:type", "website", true);

    const navLinks = $("#nav-links");
    site.nav.forEach(item => { const a = el("a", null, item.label); a.setAttribute("href", item.href); navLinks.appendChild(a); });
    const navCta = $("#nav-cta");
    if (navCta && site.navCta) { navCta.textContent = site.navCta.label; navCta.setAttribute("href", site.navCta.href); }
    $("#brand").innerHTML = `<img src="${brand.logo}" alt="${brand.name} logo"><span class="cn">${brand.cn}</span>`;

    /* Hero（视频 + 双头像，头像可点头像弹窗） */
    const h = site.hero;
    $("#hero-tag").textContent = h.tag;
    $("#hero-title").textContent = h.title;
    const heroCn = $("#hero-cn");
    if (h.cn) { heroCn.textContent = h.cn; heroCn.style.display = ""; }
    else { heroCn.textContent = ""; heroCn.style.display = "none"; }
    $("#hero-desc").textContent = h.desc;
    $("#cta-primary").textContent = h.ctaPrimary.label;
    $("#cta-primary").setAttribute("href", h.ctaPrimary.href);
    $("#cta-secondary").textContent = h.ctaSecondary.label;
    $("#cta-secondary").setAttribute("href", h.ctaSecondary.href);
    const heroSrc = $("#hero-src");
    if (heroSrc) heroSrc.setAttribute("src", h.video);
    const heroVideo = $("#hero-video");
    if (heroVideo) { try { heroVideo.load(); } catch (e) {} }
    const heroAvatars = $("#hero-avatars");
    (h.avatars || []).forEach(id => {
      const host = S.hosts[id];
      if (!host) return;
      const b = el("button", "hero-avatar-btn");
      b.type = "button";
      b.setAttribute("aria-label", "查看主播 " + host.name);
      b.innerHTML = `<img src="${host.avatar}" alt="${host.alt}" width="52" height="52">`;
      b.addEventListener("click", () => openHostModal(id));
      heroAvatars.appendChild(b);
    });
    const scribbles = $("#hero-scribbles");
    (h.scribbles || []).forEach(t => scribbles.appendChild(el("span", "scribble", t)));

    /* 关于 */
    $("#about-title").textContent = site.about.title;
    const aboutP = $("#about-paragraphs");
    site.about.paragraphs.forEach(p => aboutP.appendChild(el("p", null, p)));
    const stats = $("#about-stats");
    site.about.stats.forEach(s => stats.appendChild(el("div", "stat", `<div class="stat-n">${s.n}</div><div class="stat-l">${s.l}</div>`)));

    /* 单集卡片列表（主入口） */
    const epWrap = $("#episode-cards");
    S.episodes.forEach(ep => {
      const card = el("a", "ep-card");
      card.setAttribute("href", "episode.html?id=" + ep.id);
      const hostImgs = (ep.hosts || []).map(id => S.hosts[id]).filter(Boolean)
        .map(hh => `<img src="${hh.avatar}" alt="${hh.alt}" width="40" height="40" loading="lazy">`).join("");
      card.innerHTML = `
        <span class="ep-badge">${ep.number}</span>
        <img class="ep-cover" src="${ep.cover}" alt="${ep.coverAlt}" width="120" height="120" loading="lazy">
        <div class="ep-title">${ep.title}</div>
        <div class="ep-meta">${ep.date} · ${ep.duration} · ${ep.tag}</div>
        <div class="ep-hostimgs" aria-label="本期主播">${hostImgs}</div>
        <span class="ep-go">进入单集 →</span>`;
      epWrap.appendChild(card);
    });
    const coming = el("div", "ep-card coming");
    coming.innerHTML = `<span class="ep-badge">EP.02</span><div class="ep-cover placeholder-cover">＋</div><div class="ep-title">敬请期待</div><div class="ep-meta">持续更新中…</div><span class="ep-go">筹备中</span>`;
    epWrap.appendChild(coming);

    /* 订阅 */
    const sub = site.subscribe;
    $("#sub-title").textContent = sub.title;
    $("#sub-input").setAttribute("placeholder", sub.placeholder);
    $("#sub-btn").textContent = sub.button;
    const socials = $("#socials");
    sub.socials.forEach(s => { const a = el("a", null, s.label); a.setAttribute("href", s.href); socials.appendChild(a); });

    /* 页脚 */
    $("#footer-brand").textContent = brand.name + " · " + brand.cn;
    $("#footer-note").textContent = `© ${site.footer.year} ${brand.name} · ${site.footer.note}`;

    bindMenu(navLinks);
    bindSubscribe();
    observeReveal();
  }

  /* =======================================================
     单集页渲染（读 ?id=）
     ======================================================= */
  function renderEpisode(S, ep) {
    if (!ep) { console.error("缺少单集数据"); return; }
    const brand = S.brand;
    document.documentElement.lang = (ep.meta && ep.meta.lang) || S.meta.lang || "zh-CN";
    document.title = (ep.meta && ep.meta.title) || S.meta.title;
    setMeta("description", (ep.meta && ep.meta.description) || S.meta.description);
    setMeta("og:title", document.title, true);
    setMeta("og:description", (ep.meta && ep.meta.description) || S.meta.description, true);
    setMeta("og:type", "website", true);

    const navLinks = $("#nav-links");
    (ep.nav || [{ label: "首页", href: "index.html" }, { label: "单集", href: "index.html#episodes" }, { label: "订阅", href: "#subscribe" }])
      .forEach(item => { const a = el("a", null, item.label); a.setAttribute("href", item.href); navLinks.appendChild(a); });
    const navCta = $("#nav-cta");
    if (navCta) navCta.remove();
    $("#brand").innerHTML = `<a href="index.html" style="display:flex;align-items:center;gap:10px;"><img src="${brand.logo}" alt="${brand.name} logo"><span class="cn">${brand.cn}</span></a>`;

    /* 标题栏 */
    $("#ep-number").textContent = ep.number;
    $("#ep-title").textContent = ep.title;
    $("#ep-sub").textContent = ep.subtitle || "";
    $("#ep-meta").textContent = [ep.date, ep.duration, ep.tag].filter(Boolean).join(" · ");
    const epCover = $("#ep-cover-img");
    if (epCover) { epCover.setAttribute("src", ep.cover); epCover.setAttribute("alt", ep.coverAlt || ep.title); }

    /* 本期主播（标题栏下方：头像 + 姓名，点头像弹窗） */
    const hostsBar = $("#ep-hosts-bar");
    (ep.hosts || []).forEach(id => {
      const ho = S.hosts[id];
      if (!ho) return;
      const b = el("button", "ep-host-chip");
      b.type = "button";
      b.setAttribute("aria-label", "查看主播 " + ho.name);
      b.innerHTML = `<img src="${ho.avatar}" alt="${ho.alt}" width="56" height="56"><span class="ep-host-name">${ho.name}</span>`;
      b.addEventListener("click", () => openHostModal(id));
      hostsBar.appendChild(b);
    });

    /* 音频占位播放器 */
    const p = ep.player || {};
    $("#player-cover").setAttribute("src", p.cover || ep.cover);
    $("#player-cover").setAttribute("alt", p.coverAlt || ep.coverAlt || ep.title);
    $("#player-title").textContent = p.title || ep.title;
    $("#player-meta").textContent = p.meta || "";
    const audio = $("#player-audio");
    const hasAudio = !!(ep.audio);
    if (hasAudio) audio.setAttribute("src", ep.audio);
    const playBtn = $("#play-btn");
    playBtn.setAttribute("aria-label", hasAudio ? "播放 " + (p.title || ep.title) : "试听占位（未上传音频）");
    playBtn.addEventListener("click", () => {
      if (hasAudio) { if (audio.paused) audio.play().catch(() => {}); else audio.pause(); }
      else { playBtn.classList.toggle("playing"); playBtn.textContent = playBtn.classList.contains("playing") ? "⏸" : "▶"; $("#player-note").textContent = "（占位音频）正式上线后点击即可收听。"; }
    });
    if (hasAudio) {
      audio.addEventListener("play", () => { playBtn.textContent = "⏸"; });
      audio.addEventListener("pause", () => { playBtn.textContent = "▶"; });
    }

    /* 简介 */
    $("#ep-intro").textContent = ep.intro || "";

    /* 详情卡片（本期内容矩阵 · 3 张精选 + 更多章节药丸） */
    const SECTION_DEFS = {
      intro: { label: "节目简介", icon: "📝" },
      timeline: { label: "时间轴 / 章节", icon: "⏱" },
      principles: { label: "双原则解析", icon: "🔑", need: "principles" },
      compare: { label: "现象对比", icon: "⚖️", need: "comparison" },
      counterex: { label: "反证与边界", icon: "❓", need: "counterexamples" },
      international: { label: "国际传播视角", icon: "🌐", need: "international" },
      clip: { label: "对谈片段", icon: "🎬", need: "player" },
      hosts: { label: "主播 / 嘉宾", icon: "🗣️" },
      links: { label: "相关链接 / 书单", icon: "🔗", need: "books" },
    };
    const grid = $("#detail-grid");
    const moreGrid = $("#more-grid");
    const buildMatrixCard = (se) => {
      const def = SECTION_DEFS[se.type];
      if (!def || (def.need && !ep[def.need])) return null;
      const card = el("button", "lineup-card t-" + (se.color || "ink"));
      card.type = "button";
      card.setAttribute("aria-label", "查看 " + (se.title || def.label));
      const artBars = Array.from({ length: 5 }).map(() => "<span></span>").join("");
      card.innerHTML = `
        <span class="lc-no">${se.no || ""}</span>
        <div class="lc-art" aria-hidden="true">${artBars}</div>
        <span class="lc-icon">${se.icon || def.icon}</span>
        <h3 class="lc-title">${se.title || def.label}</h3>
        <p class="lc-sub">${se.sub || ""}</p>
        <span class="lc-more">进入</span>`;
      card.addEventListener("click", () => openSectionModal(ep, se.type));
      return card;
    };
    (ep.matrix || []).forEach(se => { const c = buildMatrixCard(se); if (c) grid.appendChild(c); });
    (ep.more || []).forEach(se => {
      const def = SECTION_DEFS[se.type];
      if (!def || (def.need && !ep[def.need])) return;
      const pill = el("button", "more-pill");
      pill.type = "button";
      pill.innerHTML = `<span class="mp-icon">${def.icon}</span>${def.label}`;
      pill.addEventListener("click", () => openSectionModal(ep, se.type));
      moreGrid.appendChild(pill);
    });

    /* 订阅（回退到 site.subscribe） */
    const sub = ep.subscribe || S.site.subscribe;
    $("#sub-title").textContent = sub.title;
    $("#sub-input").setAttribute("placeholder", sub.placeholder);
    $("#sub-btn").textContent = sub.button;
    const socials = $("#socials");
    sub.socials.forEach(s => { const a = el("a", null, s.label); a.setAttribute("href", s.href); socials.appendChild(a); });

    $("#footer-brand").textContent = brand.name + " · " + brand.cn;
    const footer = ep.footer || S.site.footer;
    $("#footer-note").textContent = `© ${footer.year} ${brand.name} · ${footer.note}`;

    bindMenu(navLinks);
    bindSubscribe();
    observeReveal();
  }

  /* 单集详情弹框内容（按 type 从结构化数据渲染） */
  function openSectionModal(ep, type) {
    let title = "", node = el("div", "section-modal");
    if (type === "intro") {
      title = "节目简介";
      node.innerHTML = `
        ${ep.subtitle ? `<div class="sm-kicker">${ep.subtitle}</div>` : ""}
        <p class="sm-lead">${ep.intro || "【占位】节目简介待补充。"}</p>
        <ul class="sm-facts">
          <li><b>发布日期</b>${ep.date || "—"}</li>
          <li><b>时长</b>${ep.duration || "—"}</li>
          <li><b>分类</b>${ep.tag || "—"}</li>
        </ul>
        <p class="sm-note">【占位】更完整的 shownotes 可在此补充。</p>`;
    } else if (type === "timeline") {
      title = "时间轴 / 章节";
      const ch = (ep.player && ep.player.chapters) || [];
      node.innerHTML = `<ol class="sm-timeline">${ch.map(c => `<li><span class="sm-time">${fmt(c.sec)}</span><span class="sm-ch ${c.theme ? "t-" + c.theme : ""}">${c.label}</span></li>`).join("")}</ol>
        <p class="sm-note">【占位】完整逐字稿时间轴可在此补充。</p>`;
    } else if (type === "principles") {
      title = "双原则解析";
      node.innerHTML = (ep.principles || []).map(pr => `
        <div class="sm-principle t-${pr.theme}">
          <div class="sm-p-icon">${pr.icon}</div>
          <div class="sm-p-name">${pr.name}</div>
          <div class="sm-p-oneliner">${pr.oneLiner}</div>
          <p class="sm-p-desc">${pr.desc}</p>
          <ul class="sm-layers">${pr.layers.map(ly => `<li><b>${ly.t}</b>　${ly.d}</li>`).join("")}</ul>
          <div class="sm-p-concl">${pr.conclusion}</div>
        </div>`).join("") + `<div class="sm-summary">结构解释形态，关系解释根源——两个原则叠在一起，才是系统分析。</div>`;
    } else if (type === "compare") {
      title = "现象对比";
      const c = ep.comparison || {};
      const col = (x) => x ? `<div class="sm-comp-col t-${x.theme}">
          <div class="sm-comp-tag">${x.tag}</div>
          <div class="sm-comp-stat">${x.stat}</div>
          <div class="sm-comp-kw">${x.keywords.map(k => `<span>${k}</span>`).join("")}</div>
          <div class="sm-comp-core">核心：${x.core}</div>
          <ul class="sm-comp-points">${x.points.map(pt => `<li>${pt}</li>`).join("")}</ul>
        </div>` : "";
      node.innerHTML = `<div class="sm-compare">${col(c.xiaohongshu)}${col(c.tiktok)}</div>`;
    } else if (type === "counterex") {
      title = "反证与边界";
      node.innerHTML = `<div class="sm-cx">${(ep.counterexamples || []).map(x => `<div class="sm-cx-card t-${x.theme}"><div class="sm-cx-label">${x.label}</div><p>${x.text}</p></div>`).join("")}</div>`;
    } else if (type === "international") {
      title = "国际传播视角";
      const intl = ep.international || {};
      node.innerHTML = `<div class="sm-intl"><div class="sm-intl-title">${intl.title || ""}</div><ul>${ (intl.points || []).map(pt => `<li>${pt}</li>`).join("") }</ul></div>`;
    } else if (type === "clip") {
      title = "本期对谈片段";
      node.innerHTML = `<div class="sm-clip"><video controls playsinline preload="metadata" poster="${(ep.player && ep.player.cover) || ep.cover}">
          <source src="assets/double-podcast.mp4" type="video/mp4">你的浏览器不支持视频播放。</video>
        <p class="sm-note">双人播客交流花絮 · ONE GLIMPSE PODCAST 幕后。</p></div>`;
    } else if (type === "hosts") {
      title = "主播 / 嘉宾";
      node.innerHTML = `<div class="sm-hosts">${(ep.hosts || []).map(id => {
        const ho = S.hosts[id]; if (!ho) return "";
        return `<div class="sm-host"><img src="${ho.avatar}" alt="${ho.alt}" width="64" height="64"><div><div class="sm-host-name">${ho.name}</div><div class="sm-host-role">${ho.role}</div><p class="sm-host-bio">${ho.bio}</p></div></div>`;
      }).join("")}</div><p class="sm-note">【占位】嘉宾信息可在此补充。</p>`;
    } else if (type === "links") {
      title = "相关链接 / 书单";
      const books = ep.books || [];
      node.innerHTML = `
        <div class="sm-books">${books.map(b => `<div class="sm-book">
            <img src="${b.cover}" alt="${b.alt}" width="56" height="76" loading="lazy">
            <div><div class="sm-book-t">${b.title}</div><div class="sm-book-a">${b.author}</div><p class="sm-book-n">${b.note}</p></div>
          </div>`).join("")}</div>
        <div class="sm-links">
          <a href="#" class="sm-link">小宇宙【占位】</a>
          <a href="#" class="sm-link">Apple Podcasts【占位】</a>
          <a href="#" class="sm-link">参考资料【占位】</a>
        </div>
        <p class="sm-note">【占位】真实收听平台与参考链接可在此补充。</p>`;
    }
    openModal(title, node);
  }

  /* =======================================================
     共用交互
     ======================================================= */
  function bindMenu(navLinks) {
    const burger = $("#hamburger");
    if (!burger) return;
    burger.addEventListener("click", () => {
      const open = navLinks.classList.toggle("open");
      burger.setAttribute("aria-expanded", open ? "true" : "false");
    });
    $$("#nav-links a").forEach(a => a.addEventListener("click", () => navLinks.classList.remove("open")));
  }

  function bindSubscribe() {
    const subForm = $("#sub-form");
    if (!subForm) return;
    subForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const input = $("#sub-input");
      if (!input.value.trim()) { input.focus(); return; }
      subForm.reset();
      alert("已收到！新节目上线会第一时间通知你 ✶");
    });
  }

  function observeReveal() {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } });
    }, { threshold: 0.12 });
    $$(".reveal").forEach(node => io.observe(node));
  }
})();
